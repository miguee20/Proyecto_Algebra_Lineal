import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton

class SumaMatricesApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Suma de Matrices")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.matriz1_label = QLabel("Matriz 1:")
        layout.addWidget(self.matriz1_label)
        self.matriz1_textedit = QTextEdit()
        layout.addWidget(self.matriz1_textedit)

        self.matriz2_label = QLabel("Matriz 2:")
        layout.addWidget(self.matriz2_label)
        self.matriz2_textedit = QTextEdit()
        layout.addWidget(self.matriz2_textedit)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.proceso_label = QLabel("Proceso:")
        layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        layout.addWidget(self.proceso_textedit)

        self.suma_button = QPushButton("Sumar")
        self.suma_button.clicked.connect(self.sumar_matrices)
        layout.addWidget(self.suma_button)

        self.setLayout(layout)

    def obtener_matriz(self, textedit):
        texto = textedit.toPlainText()
        filas = texto.strip().split('\n')
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

    def mostrar_matriz(self, matriz, textedit):
        texto = ''
        for fila in matriz:
            texto += ' '.join(str(elemento) for elemento in fila) + '\n'
        textedit.setPlainText(texto)

    def mostrar_proceso(self, proceso, textedit):
        texto = '\n'.join([f"Paso {i+1}: {paso}" for i, paso in enumerate(proceso)])
        textedit.setPlainText(texto)

    def sumar_matrices(self):
        matriz1 = self.obtener_matriz(self.matriz1_textedit)
        matriz2 = self.obtener_matriz(self.matriz2_textedit)

        if len(matriz1) != len(matriz2) or len(matriz1[0]) != len(matriz2[0]):
            self.resultado_textedit.setPlainText("Las matrices deben tener la misma dimensión.")
            self.proceso_textedit.setPlainText("")
            return

        paso_a_paso = []
        resultado = [[matriz1[i][j] + matriz2[i][j] for j in range(len(matriz1[0]))] for i in range(len(matriz1))]
        for i in range(len(matriz1)):
            paso = [f"{matriz1[i][j]} + {matriz2[i][j]} = {resultado[i][j]}" for j in range(len(matriz1[0]))]
            paso_a_paso.append(' '.join(paso))

        self.mostrar_proceso(paso_a_paso, self.proceso_textedit)
        self.mostrar_matriz(resultado, self.resultado_textedit)

