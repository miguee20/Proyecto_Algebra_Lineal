import sys
import numpy as np
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QMessageBox

# Global list to hold the key matrix
key = []

# Letter to number mappings
mapping = {
    'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8,
    'i': 9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'ñ': 15,
    'o': 16, 'p': 17, 'q': 18, 'r': 19, 's': 20, 't': 21, 'u': 22,
    'v': 23, 'w': 24, 'x': 25, 'y': 26, 'z': 27, ' ': 28, '0': 29,
    '1': 30, '2': 31, '3': 32, '4': 33, '5': 34, '6': 35, '7': 36,
    '8': 37, '9': 38, '.': 39, ',': 40, ':': 41, ';': 42, '?': 43,
    '!': 44, '"': 45, '(': 46, ')': 47, '[': 48, ']': 49,
    '{': 50, '}': 51, '@': 52, '#': 53, '$': 54, '%': 55, '&': 56,
    '*': 57, '+': 58, '-': 59, '/': 60, '|': 61, '<': 62,
    '>': 63, '=': 64, '_': 65, '^': 66, '`': 67, '~': 68
}

def matriz_reversed(matriz):
    try:
        inversa = np.linalg.inv(matriz)
        return inversa
    except np.linalg.LinAlgError:
        return None

class MatrixDecryptionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Descifrado de Matrices")
        self.setGeometry(400, 210, 750, 600)

        layout = QVBoxLayout()

        self.ciphered_matrix_label = QLabel("Ingrese la matriz cifrada (separada por espacios y sin caracteres especiales):")
        layout.addWidget(self.ciphered_matrix_label)
        self.ciphered_matrix_textedit = QTextEdit()
        layout.addWidget(self.ciphered_matrix_textedit)

        self.key_matrix_label = QLabel("Ingrese la matriz de la llave:")
        layout.addWidget(self.key_matrix_label)
        self.key_matrix_textedit = QTextEdit()
        layout.addWidget(self.key_matrix_textedit)

        self.result_label = QLabel("Resultado:")
        layout.addWidget(self.result_label)
        self.result_textedit = QTextEdit()
        self.result_textedit.setReadOnly(True)
        layout.addWidget(self.result_textedit)

        self.step_by_step_label = QLabel("Procedimiento paso por paso:")
        layout.addWidget(self.step_by_step_label)
        self.step_by_step_textedit = QTextEdit()
        self.step_by_step_textedit.setReadOnly(True)
        layout.addWidget(self.step_by_step_textedit)

        self.decrypted_message_label = QLabel("Mensaje descifrado:")
        layout.addWidget(self.decrypted_message_label)
        self.decrypted_message_textedit = QTextEdit()
        self.decrypted_message_textedit.setReadOnly(True)
        layout.addWidget(self.decrypted_message_textedit)

        self.confirm_button = QPushButton("Confirmar")
        self.confirm_button.clicked.connect(self.confirm_button_action)
        layout.addWidget(self.confirm_button)

        self.setLayout(layout)

    def confirm_button_action(self):
        ciphered_matrix_text = self.ciphered_matrix_textedit.toPlainText().strip()
        key_matrix_text = self.key_matrix_textedit.toPlainText().strip()

        try:
            ciphered_matrix_values = list(map(float, ciphered_matrix_text.split()))
            ciphered_matrix = np.array(ciphered_matrix_values).reshape(3, -1)
        except ValueError:
            self.show_error_message("La matriz cifrada contiene valores no válidos.")
            return
        except Exception:
            self.show_error_message("La matriz cifrada no puede ser redimensionada a una matriz 3xN.")
            return

        try:
            key_matrix = np.array([[float(num) for num in row.split()] for row in key_matrix_text.split('\n')])
            if key_matrix.shape != (3, 3):
                raise ValueError
        except ValueError:
            self.show_error_message("La matriz de la llave debe ser una matriz 3x3 con valores numéricos.")
            return

        # Proceso de descifrado
        result = f'Matriz cifrada:\n{ciphered_matrix}\n\n'
        result += f'Matriz de llave:\n{key_matrix}\n\n'

        step_by_step = "Procedimiento de multiplicación de matrices:\n\n"

        matrix_reversed_np = matriz_reversed(key_matrix)
        if matrix_reversed_np is None:
            result += "La matriz de llave no es invertible.\n"
        else:
            matrix_original = np.zeros(ciphered_matrix.shape)

            for i in range(3):
                for j in range(ciphered_matrix.shape[1]):
                    cell_value = 0
                    for k in range(3):
                        cell_value += matrix_reversed_np[i, k] * ciphered_matrix[k, j]
                        step_by_step += f'{matrix_reversed_np[i, k]} * {ciphered_matrix[k, j]} + '
                    matrix_original[i, j] = cell_value
                    step_by_step = step_by_step[:-3] + f' = {cell_value}\n'

            result += f'Matriz inversa de la llave:\n{matrix_reversed_np}\n\n'
            result += f'Matriz descifrada (texto original):\n{matrix_original}\n\n'

            # Convertir la matriz descifrada de vuelta a texto
            texto_descifrado = []
            for i in range(matrix_original.shape[1]):
                for j in range(3):
                    valor = round(matrix_original[j, i])
                    letra = next((k for k, v in mapping.items() if v == valor), '?')
                    texto_descifrado.append(letra)
            result += f'Texto descifrado:\n{"".join(texto_descifrado).strip()}\n'

        self.result_textedit.setPlainText(result)
        self.step_by_step_textedit.setPlainText(step_by_step)
        self.decrypted_message_textedit.setPlainText("".join(texto_descifrado).strip())

    def show_error_message(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setWindowTitle("Error")
        msg.setText(message)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MatrixDecryptionWindow()
    window.show()
    sys.exit(app.exec())
