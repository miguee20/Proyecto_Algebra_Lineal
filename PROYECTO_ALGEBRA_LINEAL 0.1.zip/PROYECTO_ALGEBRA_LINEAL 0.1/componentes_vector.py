import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QLineEdit, QGridLayout, QSpinBox
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
import numpy as np

class ComponentesVectores(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Componentes de Vectores")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.num_vectores_label = QLabel("Número de vectores:")
        layout.addWidget(self.num_vectores_label)
        
        self.num_vectores_spinbox = QSpinBox()
        self.num_vectores_spinbox.setMinimum(1)
        layout.addWidget(self.num_vectores_spinbox)

        self.ingresar_datos_button = QPushButton("Ingresar Datos de Vectores")
        self.ingresar_datos_button.clicked.connect(self.ingresar_datos)
        layout.addWidget(self.ingresar_datos_button)

        self.vectores_layout = QGridLayout()
        layout.addLayout(self.vectores_layout)

        self.calcular_button = QPushButton("Calcular Componentes")
        self.calcular_button.clicked.connect(self.calcular_componentes)
        self.calcular_button.setEnabled(False)
        layout.addWidget(self.calcular_button)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.setLayout(layout)

    def ingresar_datos(self):
        self.calcular_button.setEnabled(True)
        num_vectores = self.num_vectores_spinbox.value()

        # Clear the previous inputs
        for i in reversed(range(self.vectores_layout.count())): 
            widget = self.vectores_layout.itemAt(i).widget()
            if widget is not None: 
                widget.deleteLater()
        
        self.vector_a_edits = []
        self.vector_b_edits = []

        for i in range(num_vectores):
            vector_a_label = QLabel(f"Vector A{i+1} (x, y):")
            self.vectores_layout.addWidget(vector_a_label, i, 0)

            vector_a_edit_x = QLineEdit()
            vector_a_edit_x.setPlaceholderText("x")
            self.vectores_layout.addWidget(vector_a_edit_x, i, 1)
            self.vector_a_edits.append(vector_a_edit_x)

            vector_a_edit_y = QLineEdit()
            vector_a_edit_y.setPlaceholderText("y")
            self.vectores_layout.addWidget(vector_a_edit_y, i, 2)
            self.vector_a_edits.append(vector_a_edit_y)

            vector_b_label = QLabel(f"Vector B{i+1} (x, y):")
            self.vectores_layout.addWidget(vector_b_label, i, 3)

            vector_b_edit_x = QLineEdit()
            vector_b_edit_x.setPlaceholderText("x")
            self.vectores_layout.addWidget(vector_b_edit_x, i, 4)
            self.vector_b_edits.append(vector_b_edit_x)

            vector_b_edit_y = QLineEdit()
            vector_b_edit_y.setPlaceholderText("y")
            self.vectores_layout.addWidget(vector_b_edit_y, i, 5)
            self.vector_b_edits.append(vector_b_edit_y)

    def calcular_componentes(self):
        vectores = []
        procedimiento = ""

        for i in range(len(self.vector_a_edits)//2):
            ax = float(self.vector_a_edits[2*i].text())
            ay = float(self.vector_a_edits[2*i+1].text())
            bx = float(self.vector_b_edits[2*i].text())
            by = float(self.vector_b_edits[2*i+1].text())
            cx = bx - ax
            cy = by - ay
            vectores.append((ax, ay, bx, by, cx, cy))
            procedimiento += (f"Vector A{i+1}: ({ax}, {ay})\n"
                              f"Vector B{i+1}: ({bx}, {by})\n"
                              f"Componentes de A a B: ({cx}, {cy})\n")

        self.resultado_textedit.setPlainText(procedimiento)
        self.graficar_vectores(vectores)

    def graficar_vectores(self, vectores):
        plt.figure()
        origin = np.array([[0, 0], [0, 0]])
        for ax, ay, bx, by, cx, cy in vectores:
            plt.quiver(*origin[:,0], [cx], [cy], angles='xy', scale_units='xy', scale=1, color='blue', label=f'Componente: ({cx}, {cy})')
            plt.quiver([ax], [ay], [bx-ax], [by-ay], angles='xy', scale_units='xy', scale=1, color='green', linestyle='--')

        plt.xlim(-10, 10)
        plt.ylim(-10, 10)
        plt.axhline(0, color='black',linewidth=0.5)
        plt.axvline(0, color='black',linewidth=0.5)
        plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
        plt.legend()
        plt.title("Componentes de Vectores")
        plt.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ComponentesVectores()
    window.show()
    sys.exit(app.exec())
