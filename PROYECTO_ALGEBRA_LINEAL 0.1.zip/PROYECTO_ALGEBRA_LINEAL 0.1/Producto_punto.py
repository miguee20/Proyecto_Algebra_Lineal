import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QLineEdit, QHBoxLayout, QGridLayout, QSpinBox
from PyQt6.QtCore import Qt

class ProductoPunto(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Producto Punto de Vectores")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.num_componentes_label = QLabel("Número de componentes por vector:")
        layout.addWidget(self.num_componentes_label)
        
        self.num_componentes_spinbox = QSpinBox()
        self.num_componentes_spinbox.setMinimum(1)
        layout.addWidget(self.num_componentes_spinbox)

        self.ingresar_datos_button = QPushButton("Ingresar Datos de Vectores")
        self.ingresar_datos_button.clicked.connect(self.ingresar_datos)
        layout.addWidget(self.ingresar_datos_button)

        self.vectores_layout = QGridLayout()
        layout.addLayout(self.vectores_layout)

        self.calcular_button = QPushButton("Calcular Producto Punto")
        self.calcular_button.clicked.connect(self.calcular_producto_punto)
        self.calcular_button.setEnabled(False)
        layout.addWidget(self.calcular_button)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.setLayout(layout)

    def ingresar_datos(self):
        self.calcular_button.setEnabled(True)
        num_componentes = self.num_componentes_spinbox.value()

        # Clear the previous inputs
        for i in reversed(range(self.vectores_layout.count())): 
            widget = self.vectores_layout.itemAt(i).widget()
            if widget is not None: 
                widget.deleteLater()
        
        self.vector1_edits = []
        self.vector2_edits = []

        for i in range(num_componentes):
            componente1_label = QLabel(f"Componente {i+1} del Vector 1:")
            self.vectores_layout.addWidget(componente1_label, i, 0)

            componente1_edit = QLineEdit()
            self.vectores_layout.addWidget(componente1_edit, i, 1)
            self.vector1_edits.append(componente1_edit)

            componente2_label = QLabel(f"Componente {i+1} del Vector 2:")
            self.vectores_layout.addWidget(componente2_label, i, 2)

            componente2_edit = QLineEdit()
            self.vectores_layout.addWidget(componente2_edit, i, 3)
            self.vector2_edits.append(componente2_edit)

    def calcular_producto_punto(self):
        vector1 = []
        vector2 = []
        procedimiento = ""

        try:
            for componente1_edit, componente2_edit in zip(self.vector1_edits, self.vector2_edits):
                componente1 = float(componente1_edit.text())
                componente2 = float(componente2_edit.text())
                vector1.append(componente1)
                vector2.append(componente2)
                producto_componente = componente1 * componente2
                procedimiento += f"{componente1} * {componente2} = {producto_componente}\n"

            producto_punto = sum(componente1 * componente2 for componente1, componente2 in zip(vector1, vector2))
            
            resultado_texto = procedimiento
            resultado_texto += f"\nProducto Punto: {producto_punto}\n"
            
            self.resultado_textedit.setPlainText(resultado_texto)

        except ValueError:
            self.resultado_textedit.setPlainText("Error: Por favor ingrese solo números en los campos de componente.")
