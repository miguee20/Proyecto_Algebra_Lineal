import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QLineEdit
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
import numpy as np
import math

class AnguloVectores(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ángulo de un Vector")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.vector_label = QLabel("Ingrese las coordenadas del vector (x, y):")
        layout.addWidget(self.vector_label)

        self.vector_edit_x = QLineEdit()
        self.vector_edit_x.setPlaceholderText("x")
        layout.addWidget(self.vector_edit_x)

        self.vector_edit_y = QLineEdit()
        self.vector_edit_y.setPlaceholderText("y")
        layout.addWidget(self.vector_edit_y)

        self.calcular_button = QPushButton("Calcular Ángulo")
        self.calcular_button.clicked.connect(self.calcular_angulo)
        layout.addWidget(self.calcular_button)

        self.graficar_button = QPushButton("Graficar Vector")
        self.graficar_button.clicked.connect(self.graficar_vector)
        layout.addWidget(self.graficar_button)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.setLayout(layout)

    def calcular_angulo(self):

        ax = float(self.vector_edit_x.text())
        ay = float(self.vector_edit_y.text())

        angulo_rad = math.atan2(ay, ax)
        angulo_deg = math.degrees(angulo_rad)

        angulo_deg = round(angulo_deg, 2)

        resultado = f"tan^(-1) (vy/vx) = {angulo_deg} grados.\n"
        resultado += "Se utiliza la formula de la tangente inversa."

        self.resultado_textedit.setPlainText(resultado)

    def graficar_vector(self):
        ax = float(self.vector_edit_x.text())
        ay = float(self.vector_edit_y.text())

        plt.figure()
        plt.quiver(0, 0, ax, ay, angles='xy', scale_units='xy', scale=1, color='blue')
        plt.xlim(-10, 10)
        plt.ylim(-10, 10)
        plt.axhline(0, color='black',linewidth=0.5)
        plt.axvline(0, color='black',linewidth=0.5)
        plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
        plt.title("Vector")
        plt.xlabel("x")
        plt.ylabel("y")
        plt.show()

