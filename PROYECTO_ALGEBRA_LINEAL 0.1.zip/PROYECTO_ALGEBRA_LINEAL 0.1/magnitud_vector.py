import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QLineEdit, QGridLayout, QSpinBox
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
import numpy as np

class MagnitudVectores(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Magnitud de Vectores")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.num_vectores_label = QLabel("Número de vectores:")
        layout.addWidget(self.num_vectores_label)
        
        self.num_vectores_spinbox = QSpinBox()
        self.num_vectores_spinbox.setMinimum(1)
        layout.addWidget(self.num_vectores_spinbox)

        self.ingresar_datos_button = QPushButton("Ingresar Datos de Vectores")
        self.ingresar_datos_button.clicked.connect(self.ingresar_datos)
        layout.addWidget(self.ingresar_datos_button)

        self.vectores_layout = QGridLayout()
        layout.addLayout(self.vectores_layout)

        self.calcular_button = QPushButton("Calcular Magnitudes")
        self.calcular_button.clicked.connect(self.calcular_magnitudes)
        self.calcular_button.setEnabled(False)
        layout.addWidget(self.calcular_button)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.setLayout(layout)

    def ingresar_datos(self):
        self.calcular_button.setEnabled(True)
        num_vectores = self.num_vectores_spinbox.value()

        # Clear the previous inputs
        for i in reversed(range(self.vectores_layout.count())): 
            widget = self.vectores_layout.itemAt(i).widget()
            if widget is not None: 
                widget.deleteLater()
        
        self.magnitud_edits = []
        self.angulo_edits = []

        for i in range(num_vectores):
            magnitud_label = QLabel(f"Magnitud del Vector {i+1}:")
            self.vectores_layout.addWidget(magnitud_label, i, 0)

            magnitud_edit = QLineEdit()
            self.vectores_layout.addWidget(magnitud_edit, i, 1)
            self.magnitud_edits.append(magnitud_edit)

            angulo_label = QLabel(f"Ángulo del Vector {i+1} (grados):")
            self.vectores_layout.addWidget(angulo_label, i, 2)

            angulo_edit = QLineEdit()
            self.vectores_layout.addWidget(angulo_edit, i, 3)
            self.angulo_edits.append(angulo_edit)

    def calcular_magnitudes(self):
        vectores = []
        procedimiento = ""

        for magnitud_edit, angulo_edit in zip(self.magnitud_edits, self.angulo_edits):
            magnitud = float(magnitud_edit.text())
            angulo = float(angulo_edit.text())
            radianes = np.deg2rad(angulo)
            x = magnitud * np.cos(radianes)
            y = magnitud * np.sin(radianes)
            vectores.append((x, y, magnitud, angulo))
            procedimiento += (f"Vector con magnitud {magnitud}, ángulo {angulo}°:\n"
                              f"  - Componente x: magnitud * cos(ángulo) = {magnitud} * cos({angulo}°) = {x:.2f}\n"
                              f"  - Componente y: magnitud * sin(ángulo) = {magnitud} * sin({angulo}°) = {y:.2f}\n")

        self.resultado_textedit.setPlainText(procedimiento)
        self.graficar_vectores(vectores)

    def graficar_vectores(self, vectores):
        plt.figure()
        origin = np.array([[0, 0], [0, 0]])
        for x, y, magnitud, angulo in vectores:
            plt.quiver(*origin[:,0], [x], [y], angles='xy', scale_units='xy', scale=1, label=f'Mag: {magnitud:.2f}, Ang: {angulo:.2f}°')

        plt.xlim(-10, 10)
        plt.ylim(-10, 10)
        plt.axhline(0, color='black',linewidth=0.5)
        plt.axvline(0, color='black',linewidth=0.5)
        plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
        plt.legend()
        plt.title("Vectores y sus Magnitudes")
        plt.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MagnitudVectores()
    window.show()
    sys.exit(app.exec())
