import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton

class MatrizInversa(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inversa de una Matriz, con Gauss Jordan")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.matriz_label = QLabel("Matriz:")
        layout.addWidget(self.matriz_label)
        self.matriz_textedit = QTextEdit()
        layout.addWidget(self.matriz_textedit)

        self.resultado_label = QLabel("Inversa:")
        layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.proceso_label = QLabel("Proceso:")
        layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        layout.addWidget(self.proceso_textedit)

        self.calcular_button = QPushButton("Calcular Inversa")
        self.calcular_button.clicked.connect(self.calcular_inversa)
        layout.addWidget(self.calcular_button)

        self.setLayout(layout)

    def obtener_matriz(self, textedit):
        texto = textedit.toPlainText()
        filas = texto.strip().split('\n')
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

    def mostrar_matriz(self, matriz, textedit):
        texto = ''
        for fila in matriz:
            texto += ' '.join(f"{elemento:.1f}" for elemento in fila) + '\n'
        textedit.setPlainText(texto)

    def mostrar_proceso(self, proceso, textedit):
        texto = '\n'.join([f"Paso {i+1}: {paso}" for i, paso in enumerate(proceso)])
        textedit.setPlainText(texto)

    def calcular_inversa(self):
        matriz = self.obtener_matriz(self.matriz_textedit)
        n = len(matriz)
        proceso = []

        
        matriz_inversa = [[1 if i == j else 0 for j in range(n)] for i in range(n)]

    
        for i in range(n):
            pivote = matriz[i][i]
            proceso.append(f"Dividir fila {i+1} por {pivote:.1f}")
            matriz[i] = [elem / pivote for elem in matriz[i]]
            matriz_inversa[i] = [elem / pivote for elem in matriz_inversa[i]]

            for j in range(i + 1, n):
                factor = matriz[j][i]
                proceso.append(f"Restar {factor:.1f} veces la fila {i+1} de la fila {j+1}")
                matriz[j] = [matriz[j][k] - factor * matriz[i][k] for k in range(n)]
                matriz_inversa[j] = [matriz_inversa[j][k] - factor * matriz_inversa[i][k] for k in range(n)]

        
        for i in range(n - 1, 0, -1):
            for j in range(i - 1, -1, -1):
                factor = matriz[j][i]
                proceso.append(f"Restar {factor:.1f} veces la fila {i+1} de la fila {j+1}")
                matriz[j] = [matriz[j][k] - factor * matriz[i][k] for k in range(n)]
                matriz_inversa[j] = [matriz_inversa[j][k] - factor * matriz_inversa[i][k] for k in range(n)]

        self.mostrar_proceso(proceso, self.proceso_textedit)
        self.mostrar_matriz(matriz_inversa, self.resultado_textedit)

