import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton

class determinante_matriz(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Determinante de una Matriz, por Sarrus y Cofactores")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.matriz_label = QLabel("Matriz:")
        layout.addWidget(self.matriz_label)
        self.matriz_textedit = QTextEdit()
        layout.addWidget(self.matriz_textedit)

        self.resultado_label = QLabel("Determinante:")
        layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.sarrus_button = QPushButton("Sarrus")
        self.sarrus_button.clicked.connect(self.calcular_determinante_sarrus)
        layout.addWidget(self.sarrus_button)

        self.cofactores_button = QPushButton("Cofactores")
        self.cofactores_button.clicked.connect(self.calcular_determinante_cofactores)
        layout.addWidget(self.cofactores_button)

        self.proceso_label = QLabel("Proceso:")
        layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        layout.addWidget(self.proceso_textedit)

        self.setLayout(layout)

    def obtener_matriz(self, textedit):
        texto = textedit.toPlainText()
        filas = texto.strip().split('\n')
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

    def mostrar_proceso(self, proceso, textedit):
        texto = '\n'.join([f"Paso {i+1}: {paso}" for i, paso in enumerate(proceso)])
        textedit.setPlainText(texto)

    def calcular_determinante_sarrus(self):
        matriz = self.obtener_matriz(self.matriz_textedit)
        n = len(matriz)
        proceso = []

        if n != 3:
            self.resultado_textedit.setPlainText("La matriz debe ser de 3x3 para utilizar el método de Sarrus.")
            self.proceso_textedit.setPlainText("")
            return

        det = (
            matriz[0][0] * matriz[1][1] * matriz[2][2] +
            matriz[0][1] * matriz[1][2] * matriz[2][0] +
            matriz[0][2] * matriz[1][0] * matriz[2][1] -
            matriz[0][2] * matriz[1][1] * matriz[2][0] -
            matriz[0][0] * matriz[1][2] * matriz[2][1] -
            matriz[0][1] * matriz[1][0] * matriz[2][2]
        )

        proceso.append(f"{matriz[0][0]} * {matriz[1][1]} * {matriz[2][2]}")
        proceso.append(f"+ {matriz[0][1]} * {matriz[1][2]} * {matriz[2][0]}")
        proceso.append(f"+ {matriz[0][2]} * {matriz[1][0]} * {matriz[2][1]}")
        proceso.append(f"- {matriz[0][2]} * {matriz[1][1]} * {matriz[2][0]}")
        proceso.append(f"- {matriz[0][0]} * {matriz[1][2]} * {matriz[2][1]}")
        proceso.append(f"- {matriz[0][1]} * {matriz[1][0]} * {matriz[2][2]}")

        self.resultado_textedit.setPlainText(str(det))
        self.mostrar_proceso(proceso, self.proceso_textedit)

    def calcular_determinante_cofactores(self):
        matriz = self.obtener_matriz(self.matriz_textedit)
        n = len(matriz)
        proceso = []

        if n != 3:
            self.resultado_textedit.setPlainText("La matriz debe ser de 3x3 para utilizar el método de cofactores.")
            self.proceso_textedit.setPlainText("")
            return

        det = (
            matriz[0][0] * (matriz[1][1] * matriz[2][2] - matriz[1][2] * matriz[2][1]) -
            matriz[0][1] * (matriz[1][0] * matriz[2][2] - matriz[1][2] * matriz[2][0]) +
            matriz[0][2] * (matriz[1][0] * matriz[2][1] - matriz[1][1] * matriz[2][0])
        )

        proceso.append(f"{matriz[0][0]} * ({matriz[1][1]} * {matriz[2][2]} - {matriz[1][2]} * {matriz[2][1]})")
        proceso.append(f"- {matriz[0][1]} * ({matriz[1][0]} * {matriz[2][2]} - {matriz[1][2]} * {matriz[2][0]})")
        proceso.append(f"+ {matriz[0][2]} * ({matriz[1][0]} * {matriz[2][1]} - {matriz[1][1]} * {matriz[2][0]})")

        self.resultado_textedit.setPlainText(str(det))
        self.mostrar_proceso(proceso, self.proceso_textedit)
