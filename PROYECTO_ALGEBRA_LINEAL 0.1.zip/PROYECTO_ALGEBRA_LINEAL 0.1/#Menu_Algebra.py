import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QStackedWidget, QLabel, QSpacerItem, QSizePolicy, QHBoxLayout
from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QFont, QPixmap
from Suma_Matrices_Intefaz import SumaMatricesApp
from Resta_Matrices_Interfaz import RestaMatricesApp
from Multiplicacion_Matrices_Intrefaz import Multiplicacion_matriz
from Cadena_Markov import Cadena_Markov
from Matriz_inversa import MatrizInversa
from Determinante_Matriz import determinante_matriz
from Rango_matriz import Rango_Matriz
from Cifrado_correcto import MatrixEncryptionWindow
from Suma_vectores import SumaVectores
from Producto_punto import ProductoPunto
from componentes_vector import ComponentesVectores
from magnitud_vector import MagnitudVectores
from Angulo_vector import AnguloVectores
from Area_Poligono import AreaPoligono
from Descifrado_correcto import MatrixDecryptionWindow

class MenuPrincipal(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))

        titulo_layout = QHBoxLayout()
        titulo = QLabel("Proyecto - Algebra Lineal")
        titulo.setFont(QFont("Arial", 22, QFont.Weight.Bold))
        titulo.setStyleSheet("font-style: italic;")

        imagen = QLabel()
        pixmap = QPixmap("C:/Users/migue/OneDrive/Escritorio/PROYECTO_ALGEBRA_LINEAL 0.1/FOTO.png")  
        if not pixmap.isNull():  
            imagen.setPixmap(pixmap.scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio))  

        titulo_layout.addStretch()
        titulo_layout.addWidget(imagen)
        titulo_layout.addWidget(titulo)
        titulo_layout.addStretch()  

        layout.addLayout(titulo_layout)

        layout.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))

        botones = [
            ("Operaciones entre Matrices", self.parent.mostrar_operaciones_matrices),
            ("Matriz Inversa", self.parent.mostrar_matriz_inversa),
            ("Determinante de una Matriz", self.parent.mostrar_determinante),
            ("Rango de una Matriz", self.parent.mostrar_rango),
            ("Cifrado por Matrices", self.parent.mostrar_cifrado_matrices),
            ("Cadenas de Markov", self.parent.mostrar_cadena_markov),
            ("Operaciones con Vectores", self.parent.mostrar_operaciones_vectores),
            ("Salir", self.salir_aplicacion)
        ]

        for texto, func in botones:
            boton = QPushButton(texto)
            boton.setStyleSheet("height: 30px; background-color: #fff8b0; color: black; border: 2px; border-radius: 13px;")
            boton.setFont(QFont("Arial", 11))
            boton.clicked.connect(func)
            layout.addWidget(boton)

        layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))

        creditos = QLabel("Hecho por: Miguel - David - Daniela ")
        creditos.setFont(QFont("Arial", 8, italic=True))
        creditos.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(creditos)

        self.setLayout(layout)

    def salir_aplicacion(self):
        QApplication.quit()

class MenuOperacionesMatrices(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        botones = [
            ("Suma de matrices", self.suma_matrices),
            ("Resta de matrices", self.resta_matrices),
            ("Multiplicación de matrices", self.multiplicacion_matrices),
            ("Volver", self.parent.mostrar_menu_principal)
        ]

        for texto, func in botones:
            boton = QPushButton(texto)
            boton.setStyleSheet("height: 30px; background-color: #fff8b0; color: black; border: 2px; border-radius: 13px;")
            boton.setFont(QFont("Arial", 11))
            boton.clicked.connect(func)
            layout.addWidget(boton)

        self.setLayout(layout)

    def suma_matrices(self):
        try:
            self.suma_matriz = SumaMatricesApp()
            self.suma_matriz.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

    def resta_matrices(self):
        try:
            self.resta_matriz = RestaMatricesApp()
            self.resta_matriz.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

    def multiplicacion_matrices(self):
        try:
            self.multiplicacion_matriz = Multiplicacion_matriz()
            self.multiplicacion_matriz.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

class MenuOperacionesVectores(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        botones = [
            ("Suma de vectores", self.suma_vectores),
            ("Producto punto de vectores", self.producto_punto_vectores),
            ("Componentes de vectores", self.componentes_vectores),
            ("Magnitud de vectores", self.magnitud_vectores),
            ("Ángulo de vectores", self.angulo_vectores),
            ("Area de poligonos irregulares", self.poligonos_irregulares),
            ("Volver", self.parent.mostrar_menu_principal)
        ]

        for texto, func in botones:
            boton = QPushButton(texto)
            boton.setStyleSheet("height: 30px; background-color: #fff8b0; color: black; border: 2px; border-radius: 13px;")
            boton.setFont(QFont("Arial", 11))
            boton.clicked.connect(func)
            layout.addWidget(boton)

        self.setLayout(layout)

    def suma_vectores(self):
        try:
            self.suma_vectores1 = SumaVectores()
            self.suma_vectores1.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

    def producto_punto_vectores(self):
        try:
            self.productopunto = ProductoPunto()
            self.productopunto.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

    def componentes_vectores(self):
        self.componentes_vectores1 = ComponentesVectores()
        self.componentes_vectores1.show()
        pass

    def magnitud_vectores(self):
        self.magnitud_vectores1 = MagnitudVectores()
        self.magnitud_vectores1.show()
        pass

    def angulo_vectores(self):
        self.angulovectores = AnguloVectores()
        self.angulovectores.show()
        pass

    def poligonos_irregulares(self):
        self.poligonosirregulares = AreaPoligono()
        self.poligonosirregulares.show()

class MenuCifradoMatrices(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        botones = [
            ("Cifrado", self.cifrado),
            ("Descifrado", self.descifrado),
            ("Volver", self.parent.mostrar_menu_principal)
        ]

        for texto, func in botones:
            boton = QPushButton(texto)
            boton.setStyleSheet("height: 30px; background-color: #fff8b0; color: black; border: 2px; border-radius: 13px;")
            boton.setFont(QFont("Arial", 11))
            boton.clicked.connect(func)
            layout.addWidget(boton)

        self.setLayout(layout)

    def cifrado(self):
        try:
            self.cifrado_matriz = MatrixEncryptionWindow()
            self.cifrado_matriz.show()
        except Exception as e:
            self.parent.mostrar_error(str(e))

    def descifrado(self):
        self.descifrado1 = MatrixDecryptionWindow()
        self.descifrado1.show()
        pass

class AplicacionOperacionesMatrices(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Proyecto Final Algebra")
        self.setFixedSize(QSize(500, 480)) 

        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.menu_principal = MenuPrincipal(self)
        self.menu_operaciones_matrices = MenuOperacionesMatrices(self)
        self.menu_operaciones_vectores = MenuOperacionesVectores(self)
        self.menu_cifrado_matrices = MenuCifradoMatrices(self)

        self.stacked_widget.addWidget(self.menu_principal)
        self.stacked_widget.addWidget(self.menu_operaciones_matrices)
        self.stacked_widget.addWidget(self.menu_operaciones_vectores)
        self.stacked_widget.addWidget(self.menu_cifrado_matrices)

        self.stacked_widget.setCurrentWidget(self.menu_principal)

    def mostrar_error(self, mensaje):
        QMessageBox.critical(self, "Error", mensaje)

    def mostrar_menu_principal(self):
        self.stacked_widget.setCurrentWidget(self.menu_principal)

    def mostrar_operaciones_matrices(self):
        self.stacked_widget.setCurrentWidget(self.menu_operaciones_matrices)

    def mostrar_matriz_inversa(self):
        try:
            self.inversa_matriz = MatrizInversa()
            self.inversa_matriz.show()
        except Exception as e:
            self.mostrar_error(str(e))

    def mostrar_determinante(self):
        try:
            self.determinante = determinante_matriz()
            self.determinante.show()
        except Exception as e:
            self.mostrar_error(str(e))

    def mostrar_rango(self):
        try:
            self.rango_matriz = Rango_Matriz()
            self.rango_matriz.show()
        except Exception as e:
            self.mostrar_error(str(e))

    def mostrar_cifrado_matrices(self):
        self.stacked_widget.setCurrentWidget(self.menu_cifrado_matrices)

    def mostrar_cadena_markov(self):
        try:
            self.cadena_markov_funcion = Cadena_Markov()
            self.cadena_markov_funcion.show()
        except Exception as e:
            self.mostrar_error(str(e))

    def mostrar_operaciones_vectores(self):
        self.stacked_widget.setCurrentWidget(self.menu_operaciones_vectores)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = AplicacionOperacionesMatrices()
    ventana.show()
    sys.exit(app.exec())
