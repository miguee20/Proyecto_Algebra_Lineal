import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton

class Rango_Matriz(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Rango de una Matriz, por Gauss y Transpuestas")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.matriz_label = QLabel("Matriz:")
        layout.addWidget(self.matriz_label)
        self.matriz_textedit = QTextEdit()
        layout.addWidget(self.matriz_textedit)

        self.transpuesta_label = QLabel("Transpuesta:")
        layout.addWidget(self.transpuesta_label)
        self.transpuesta_textedit = QTextEdit()
        layout.addWidget(self.transpuesta_textedit)

        self.resultado_label = QLabel("Rango:")
        layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.rango_gauss_button = QPushButton("Calcular Rango (Gaussiana)")
        self.rango_gauss_button.clicked.connect(self.calcular_rango_gauss)
        layout.addWidget(self.rango_gauss_button)

        self.rango_transpuesta_button = QPushButton("Calcular Rango (Transpuesta)")
        self.rango_transpuesta_button.clicked.connect(self.calcular_rango_transpuesta)
        layout.addWidget(self.rango_transpuesta_button)

        self.proceso_label = QLabel("Proceso:")
        layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        layout.addWidget(self.proceso_textedit)

        self.setLayout(layout)

    def obtener_matriz(self, textedit):
        texto = textedit.toPlainText()
        filas = texto.strip().split('\n')
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

    def mostrar_matriz(self, matriz, textedit):
        texto = '\n'.join([' '.join(map(str, fila)) for fila in matriz])
        textedit.setPlainText(texto)

    def mostrar_proceso(self, proceso, textedit):
        texto = '\n'.join([f"Paso {i+1}:\n{paso}" for i, paso in enumerate(proceso)])
        textedit.setPlainText(texto)

    def transponer_matriz(self, matriz):
        return [list(fila) for fila in zip(*matriz)]

    def reducir_fila(self, matriz):
        n = len(matriz)
        m = len(matriz[0])
        proceso = []
        for i in range(min(n, m)):
            if matriz[i][i] == 0:
                for j in range(i+1, n):
                    if matriz[j][i] != 0:
                        matriz[i], matriz[j] = matriz[j], matriz[i]
                        proceso.append(f"Intercambiamos la fila {i+1} con la fila {j+1}:\n{self.matriz_a_texto(matriz)}")
                        break
            if matriz[i][i] == 0:
                continue
            for j in range(i+1, n):
                if matriz[j][i] != 0:
                    ratio = matriz[j][i] / matriz[i][i]
                    matriz[j] = [matriz[j][k] - ratio * matriz[i][k] for k in range(m)]
                    proceso.append(f"Restamos {ratio:.2f} veces la fila {i+1} de la fila {j+1}:\n{self.matriz_a_texto(matriz)}")
        return matriz, proceso

    def eliminacion_gaussiana(self, matriz):
        n = len(matriz)
        m = len(matriz[0])
        proceso = []

        for i in range(min(n, m)):
            # Buscar el máximo en la columna i
            max_row = i
            for k in range(i + 1, n):
                if abs(matriz[k][i]) > abs(matriz[max_row][i]):
                    max_row = k

            # Intercambiar la fila max_row con la fila i
            if i != max_row:
                matriz[i], matriz[max_row] = matriz[max_row], matriz[i]
                proceso.append(f"Intercambiamos la fila {i+1} con la fila {max_row+1}:\n{self.matriz_a_texto(matriz)}")

            # Hacer nulos los elementos debajo de matriz[i][i]
            if matriz[i][i] != 0:
                for k in range(i + 1, n):
                    ratio = matriz[k][i] / matriz[i][i]
                    for j in range(i, m):
                        matriz[k][j] -= ratio * matriz[i][j]
                    proceso.append(f"Restamos {ratio:.2f} veces la fila {i+1} de la fila {k+1}:\n{self.matriz_a_texto(matriz)}")
            else:
                proceso.append(f"No se puede eliminar el elemento de la fila {i+1}, columna {i+1} porque es cero:\n{self.matriz_a_texto(matriz)}")

        return matriz, proceso

    def matriz_a_texto(self, matriz):
        return '\n'.join([' '.join([f"{elem:.2f}" for elem in fila]) for fila in matriz])

    def calcular_rango_gauss(self):
        matriz = self.obtener_matriz(self.matriz_textedit)
        matriz_reducida, proceso = self.eliminacion_gaussiana(matriz)
        rango = sum(any(fila) for fila in matriz_reducida)

        self.resultado_textedit.setPlainText(str(rango))
        self.mostrar_proceso(proceso, self.proceso_textedit)

    def calcular_rango_transpuesta(self):
        matriz = self.obtener_matriz(self.matriz_textedit)
        transpuesta = self.transponer_matriz(matriz)
        self.mostrar_matriz(transpuesta, self.transpuesta_textedit)

        matriz_reducida, proceso = self.reducir_fila(transpuesta)
        rango = sum(any(fila) for fila in matriz_reducida)

        self.resultado_textedit.setPlainText(str(rango))
        self.mostrar_proceso(proceso, self.proceso_textedit)
