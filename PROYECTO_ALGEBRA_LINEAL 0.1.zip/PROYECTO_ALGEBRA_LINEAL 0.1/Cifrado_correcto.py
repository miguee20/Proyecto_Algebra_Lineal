import sys
import numpy as np
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QMessageBox

# Global lists to hold text conversion and key matrix
lista = []

# Letter to number mappings
mapping = {
    'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8,
    'i': 9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'ñ': 15,
    'o': 16, 'p': 17, 'q': 18, 'r': 19, 's': 20, 't': 21, 'u': 22,
    'v': 23, 'w': 24, 'x': 25, 'y': 26, 'z': 27, ' ': 28, '0': 29,
    '1': 30, '2': 31, '3': 32, '4': 33, '5': 34, '6': 35, '7': 36,
    '8': 37, '9': 38, '.': 39, ',': 40, ':': 41, ';': 42, '?': 43,
    '!': 44, '"': 45, '(': 46, ')': 47, '[': 48, ']': 49,
    '{': 50, '}': 51, '@': 52, '#': 53, '$': 54, '%': 55, '&': 56,
    '*': 57, '+': 58, '-': 59, '/': 60, '|': 61, '<': 62,
    '>': 63, '=': 64, '_': 65, '^': 66, '`': 67, '~': 68
}

def encrypt(text):
    lista.clear()
    for letra in text:
        lista.append(mapping.get(letra.lower(), 'Opción Incorrecta!'))
    size()

def size():
    while len(lista) % 3 != 0:
        lista.append(28)

class MatrixEncryptionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cifrado de Matrices")
        self.setGeometry(400, 210, 750, 600)

        layout = QVBoxLayout()

        self.message_label = QLabel("Ingrese el mensaje a encriptar (sin caracteres especiales):")
        layout.addWidget(self.message_label)
        self.message_textedit = QTextEdit()
        layout.addWidget(self.message_textedit)

        self.matrix_label = QLabel("Matriz (llave) 3x3, ingrese los valores separados por espacios:")
        layout.addWidget(self.matrix_label)
        self.matrix_textedit = QTextEdit()
        layout.addWidget(self.matrix_textedit)

        self.result_label = QLabel("Resultado:")
        layout.addWidget(self.result_label)
        self.result_textedit = QTextEdit()
        self.result_textedit.setReadOnly(True)
        layout.addWidget(self.result_textedit)

        self.step_by_step_label = QLabel("Procedimiento paso por paso:")
        layout.addWidget(self.step_by_step_label)
        self.step_by_step_textedit = QTextEdit()
        self.step_by_step_textedit.setReadOnly(True)
        layout.addWidget(self.step_by_step_textedit)

        self.encrypted_numbers_label = QLabel("Números cifrados:")
        layout.addWidget(self.encrypted_numbers_label)
        self.encrypted_numbers_textedit = QTextEdit()
        self.encrypted_numbers_textedit.setReadOnly(True)
        layout.addWidget(self.encrypted_numbers_textedit)

        self.confirm_button = QPushButton("Confirmar")
        self.confirm_button.clicked.connect(self.confirm_button_action)
        layout.addWidget(self.confirm_button)

        self.setLayout(layout)

    def confirm_button_action(self):
        message = (self.message_textedit.toPlainText()).strip()
        encrypt(message)

        try:
            key = self.get_matrix_from_textedit(self.matrix_textedit)
        except ValueError as e:
            QMessageBox.warning(self, "Error de caracteres", str(e))
            return

        key_np = np.array(key)
        number_columns = -(-len(lista) // 3)
        matrix = np.zeros((3, number_columns))

        for il, valor in enumerate(lista):
            rows = il % 3
            columns = il // 3
            matrix[rows, columns] = valor

        # Mostrar el proceso de cifrado
        result = f'Texto convertido a números:\n{lista}\n\n'
        result += f'Matriz de texto antes del cifrado:\n{matrix}\n\n'
        result += f'Matriz de llave:\n{key_np}\n\n'

        step_by_step = "Procedimiento de multiplicación de matrices:\n\n"
        matrix_cifrada = np.zeros((3, number_columns))

        for i in range(3):
            for j in range(number_columns):
                cell_value = 0
                for k in range(3):
                    cell_value += key_np[i, k] * matrix[k, j]
                    step_by_step += f'{key_np[i, k]} * {matrix[k, j]} + '
                matrix_cifrada[i, j] = cell_value
                step_by_step = step_by_step[:-3] + f' = {cell_value}\n'

        result += f'Matriz cifrada:\n{matrix_cifrada}\n\n'

        # Convert the encrypted matrix to a list of numbers in the specified format
        encrypted_numbers = []
        for i in range(3):
            for j in range(number_columns):
                encrypted_numbers.append(matrix_cifrada[i, j])
        encrypted_numbers_str = ' '.join(map(lambda x: str(int(x)), encrypted_numbers))

        self.result_textedit.setPlainText(result)
        self.step_by_step_textedit.setPlainText(step_by_step)
        self.encrypted_numbers_textedit.setPlainText(encrypted_numbers_str)

    def get_matrix_from_textedit(self, textedit):
        texto = textedit.toPlainText().strip()
        filas = texto.split('\n')
        if len(filas) != 3:
            raise ValueError("La matriz llave debe tener exactamente 3 filas.")
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            if len(elementos) != 3:
                raise ValueError("Cada fila de la matriz llave debe tener exactamente 3 elementos.")
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MatrixEncryptionWindow()
    window.show()
    sys.exit(app.exec())
