import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QGridLayout, QTextEdit, QSpinBox, QLineEdit, QHBoxLayout
import matplotlib.pyplot as plt
import numpy as np

class AreaPoligono(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Área de Polígono Irregular")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.num_puntos_label = QLabel("Número de puntos:")
        layout.addWidget(self.num_puntos_label)
        
        self.num_puntos_spinbox = QSpinBox()
        self.num_puntos_spinbox.setMinimum(3)
        layout.addWidget(self.num_puntos_spinbox)

        self.ingresar_puntos_button = QPushButton("Ingresar Puntos del Polígono")
        self.ingresar_puntos_button.clicked.connect(self.ingresar_puntos)
        layout.addWidget(self.ingresar_puntos_button)

        self.calcular_button = QPushButton("Calcular Área")
        self.calcular_button.clicked.connect(self.calcular_area)
        self.calcular_button.setEnabled(False)
        layout.addWidget(self.calcular_button)

        self.graficar_button = QPushButton("Ver Gráfico")
        self.graficar_button.clicked.connect(self.graficar_poligono)
        self.graficar_button.setEnabled(False)
        layout.addWidget(self.graficar_button)

        self.resultado_label = QLabel("Procedimiento:")
        layout.addWidget(self.resultado_label)
        
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.setLayout(layout)

    def ingresar_puntos(self):
        self.calcular_button.setEnabled(True)
        self.puntos_layout = QGridLayout()
        num_puntos = self.num_puntos_spinbox.value()

        if hasattr(self, 'puntos_edit'):
            for edit in self.puntos_edit:
                edit.deleteLater()
            self.layout().removeItem(self.puntos_layout)

        self.puntos_edit = []

        for i in range(num_puntos):
            punto_label = QLabel(f"Punto {i+1} (x, y):")
            edit = QLineEdit()
            edit.setPlaceholderText("x, y")
            self.puntos_edit.append(edit)
            layout = QHBoxLayout()
            layout.addWidget(punto_label)
            layout.addWidget(edit)
            self.puntos_layout.addLayout(layout, i, 0)

        self.layout().addSpacing(20)  

        self.layout().addLayout(self.puntos_layout) 

    def calcular_area(self):
        puntos = []

        procedimiento = "Procedimiento:\n"
        
        for edit in self.puntos_edit:
            coords = edit.text().split(',')
            if len(coords) != 2:
                self.resultado_textedit.setPlainText("Error: Por favor, ingrese coordenadas válidas (x, y) para todos los puntos.")
                return
            try:
                x, y = map(float, coords)
            except ValueError:
                self.resultado_textedit.setPlainText("Error: Por favor, ingrese coordenadas numéricas válidas (x, y) para todos los puntos.")
                return
            puntos.append((x, y))

        area, procedimiento_area = self.calcular_area_poligono(puntos)
        procedimiento += procedimiento_area

        self.resultado_textedit.setPlainText(f"Área del polígono: {area}\n\n{procedimiento}")
        self.graficar_button.setEnabled(True)

    def calcular_area_poligono(self, puntos):
        area = 0
        n = len(puntos)
        procedimiento = ""
        for i in range(n):
            j = (i + 1) % n
            area += puntos[i][0] * puntos[j][1]
            area -= puntos[j][0] * puntos[i][1]
            procedimiento += f"({puntos[i][0]} * {puntos[j][1]}) - ({puntos[j][0]} * {puntos[i][1]}) + "
        area = abs(area) / 2.0
        procedimiento = procedimiento[:-2]  
        procedimiento += f"\nÁrea del polígono: {area} unidades cuadradas\n"

        matriz_procedimiento = "Matriz de la fórmula de la lázada:\n"
        for punto in puntos:
            matriz_procedimiento += f"| {punto[0]}  {punto[1]} |\n"
        matriz_procedimiento += f"| {puntos[0][0]}  {puntos[0][1]} |\n"

        procedimiento += f"\n{matriz_procedimiento}"

        return area, procedimiento

    def graficar_poligono(self):
        puntos = []
        for edit in self.puntos_edit:
            coords = edit.text().split(',')
            x, y = map(float, coords)
            puntos.append((x, y))

        plt.figure()
        x = [p[0] for p in puntos]
        y = [p[1] for p in puntos]
        plt.plot(x, y, 'bo-')
        plt.fill(x, y, alpha=0.3, color='lightblue')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title('Polígono Irregular')
        plt.grid(True)
        plt.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = AreaPoligono()
    window.show()
    sys.exit(app.exec())
