import sys
import numpy as np
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QGridLayout, QSpinBox, QTextEdit

class Cadena_Markov(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cadenas de Markov")
        self.setGeometry(100, 100, 600, 400)
        self.layout = QVBoxLayout()

        self.layout.addWidget(QLabel("Dimensión de la matriz:"))
        self.dimension_input = QSpinBox(self)
        self.dimension_input.setRange(2, 10)  
        self.dimension_input.setValue(3)
        self.layout.addWidget(self.dimension_input)

        self.set_dimensions_button = QPushButton("Establecer dimensiones", self)
        self.set_dimensions_button.clicked.connect(self.set_dimensions)
        self.layout.addWidget(self.set_dimensions_button)

        self.setLayout(self.layout)
    
    def set_dimensions(self):
        self.dimension = self.dimension_input.value()

        while self.layout.count():
            child = self.layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        self.names = [QLineEdit(self) for _ in range(self.dimension)]
        for i, name in enumerate(self.names):
            self.layout.addWidget(QLabel(f"Nombre {i+1}:"))
            self.layout.addWidget(name)
        
        self.grid = QGridLayout()
        self.transitions = [[QLineEdit(self) for _ in range(self.dimension)] for _ in range(self.dimension)]
        for i in range(self.dimension):
            for j in range(self.dimension):
                self.grid.addWidget(self.transitions[i][j], i, j)
        
        self.layout.addLayout(self.grid)

        self.vector_input = [QLineEdit(self) for _ in range(self.dimension)]
        self.layout.addWidget(QLabel("Matriz de estado inicial (n x 1):"))
        vector_layout = QVBoxLayout()
        for i in range(self.dimension):
            vector_layout.addWidget(self.vector_input[i])
        self.layout.addLayout(vector_layout)

        self.layout.addWidget(QLabel("Número de iteraciones:"))
        self.iterations_input = QSpinBox(self)
        self.iterations_input.setRange(1, 100)
        self.layout.addWidget(self.iterations_input)

        self.calculate_button = QPushButton("Calcular", self)
        self.calculate_button.clicked.connect(self.calculate_probabilities)
        self.layout.addWidget(self.calculate_button)

        self.resultado_label = QLabel("Probabilidades después de iteraciones:")
        self.layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        self.layout.addWidget(self.resultado_textedit)

        self.proceso_label = QLabel("Proceso:")
        self.layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        self.layout.addWidget(self.proceso_textedit)

        self.setLayout(self.layout)
    
    def obtener_matriz_transicion(self):
        try:
            matriz = np.array([[float(self.transitions[i][j].text()) for j in range(self.dimension)] for i in range(self.dimension)])
            return matriz
        except ValueError:
            self.resultado_textedit.setPlainText("Error: Todos los valores de la matriz deben ser números.")
            return None

    def obtener_vector_inicial(self):
        try:
            vector = np.array([float(self.vector_input[i].text()) for i in range(self.dimension)]).reshape((self.dimension, 1))
            return vector
        except ValueError:
            self.resultado_textedit.setPlainText("Error: Todos los valores del vector deben ser números.")
            return None

    def calculate_probabilities(self):
        names = [name.text() for name in self.names]
        transition_matrix = self.obtener_matriz_transicion()
        state_vector = self.obtener_vector_inicial()

        if transition_matrix is None or state_vector is None:
            return
        
        if not np.allclose(transition_matrix.sum(axis=1), 1):
            self.resultado_textedit.setPlainText("Error: Las filas de la matriz de transición deben sumar 1.")
            return

        iterations = self.iterations_input.value()

        steps = ["Matriz original:\n" + self.matriz_a_texto(transition_matrix)]
        steps.append("Vector inicial:\n" + self.vector_a_texto(state_vector))

        transition_matrix = transition_matrix.T
        steps.append("Matriz transpuesta:\n" + self.matriz_a_texto(transition_matrix))

        state_vector = transition_matrix @ state_vector
        steps.append("Vector después de la primera multiplicación:\n" + self.vector_a_texto(state_vector))

        for i in range(iterations):
            state_vector = transition_matrix @ state_vector
            steps.append(f"Paso {i+1}:\n" + "\n".join([f"{name}: {prob[0]:.4f}" for name, prob in zip(names, state_vector)]))

        result = "\n".join(steps)
        final_result = "\n".join([f"{name}: {prob[0]:.4f}" for name, prob in zip(names, state_vector)])
        self.resultado_textedit.setPlainText(f"Probabilidades después de {iterations} iteraciones:\n{final_result}")
        self.proceso_textedit.setPlainText(result)

    def matriz_a_texto(self, matriz):
        return '\n'.join([' '.join([f"{elem:.4f}" for elem in fila]) for fila in matriz])
    
    def vector_a_texto(self, vector):
        return '\n'.join([f"{elem[0]:.4f}" for elem in vector])

