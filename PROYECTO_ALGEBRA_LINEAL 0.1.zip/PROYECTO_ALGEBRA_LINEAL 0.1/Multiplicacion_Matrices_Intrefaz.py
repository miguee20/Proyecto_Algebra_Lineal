import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton

class Multiplicacion_matriz(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Multiplicación de Matrices")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.matriz1_label = QLabel("Matriz 1:")
        layout.addWidget(self.matriz1_label)
        self.matriz1_textedit = QTextEdit()
        layout.addWidget(self.matriz1_textedit)

        self.matriz2_label = QLabel("Matriz 2:")
        layout.addWidget(self.matriz2_label)
        self.matriz2_textedit = QTextEdit()
        layout.addWidget(self.matriz2_textedit)

        self.resultado_label = QLabel("Resultado:")
        layout.addWidget(self.resultado_label)
        self.resultado_textedit = QTextEdit()
        layout.addWidget(self.resultado_textedit)

        self.proceso_label = QLabel("Proceso:")
        layout.addWidget(self.proceso_label)
        self.proceso_textedit = QTextEdit()
        layout.addWidget(self.proceso_textedit)

        buttons_layout = QHBoxLayout()

        self.multiplicacion_button = QPushButton("Multiplicar")
        self.multiplicacion_button.clicked.connect(self.multiplicar_matrices)
        buttons_layout.addWidget(self.multiplicacion_button)

        layout.addLayout(buttons_layout)

        self.setLayout(layout)

    def obtener_matriz(self, textedit):
        texto = textedit.toPlainText()
        filas = texto.strip().split('\n')
        matriz = []
        for fila in filas:
            elementos = fila.strip().split()
            fila_matriz = [float(elemento) for elemento in elementos]
            matriz.append(fila_matriz)
        return matriz

    def mostrar_matriz(self, matriz, textedit):
        texto = ''
        for fila in matriz:
            texto += ' '.join(str(elemento) for elemento in fila) + '\n'
        textedit.setPlainText(texto)

    def mostrar_proceso(self, proceso, textedit):
        texto = '\n'.join([f"{paso}" for paso in proceso])
        textedit.setPlainText(texto)

    def multiplicar_matrices(self):
        matriz1 = self.obtener_matriz(self.matriz1_textedit)
        matriz2 = self.obtener_matriz(self.matriz2_textedit)

        if len(matriz1[0]) != len(matriz2):
            self.resultado_textedit.setPlainText("El número de columnas de la matriz 1 debe ser igual al número de filas de la matriz 2.")
            self.proceso_textedit.setPlainText("")
            return

        paso_a_paso = []
        resultado = [[0 for _ in range(len(matriz2[0]))] for _ in range(len(matriz1))]

        for i in range(len(matriz1)):
            for j in range(len(matriz2[0])):
                suma = 0
                paso = []
                for k in range(len(matriz2)):
                    operacion = f"{matriz1[i][k]} * {matriz2[k][j]}"
                    paso.append(operacion)
                    suma += matriz1[i][k] * matriz2[k][j]
                resultado[i][j] = suma
                paso_a_paso.append(f"Paso {i*len(matriz2[0]) + j + 1}: " + ' + '.join(paso) + f" = {suma}")

        self.mostrar_proceso(paso_a_paso, self.proceso_textedit)
        self.mostrar_matriz(resultado, self.resultado_textedit)
